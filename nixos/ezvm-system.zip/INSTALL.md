# Install

**The install erases the whole disk you choose.** Save anything you want to keep somewhere
else first.

You need an internet connection (a cable is easiest) and a disk that may be erased.

The computer has to start with UEFI (EFI): this setup boots with systemd-boot, which does not
work on an old BIOS (legacy) start.

## Steps

1. Press **Install this setup (Guided)**. A text window opens at the bottom of the page.
2. Type the name of the disk to erase (for example `sda` or `nvme0n1`) and press Enter. Type
   it once more to confirm.
3. Wait for **Install finished**. Do not turn the computer off before that.
4. Remove the USB stick and press **Ezmenu**, then **Reboot**.
5. Log in with username `nixos` and password `eznix`, then change the password (Start
   menu, System Settings, Users).

## Changing the setup first (optional)

Do this before step 1 if you want other programs, another keyboard layout and so on.

1. Click through the tabs at the top and change what you want. To add a setting, right-click
   and choose **Add option…**.
2. Press **Save**. Without it your changes are not installed.

The text editor on the install stick, used from the terminal at the bottom, is
**micro**. Press **Ctrl+S** to save and **Ctrl+Q** to quit.

You can also change all of this after the install.
