# Your new computer

This folder is a ready-made setup for a desktop computer running NixOS with KDE. You change
it by clicking in a web page called **eznix**, not by editing files.

To install it, follow [INSTALL.md](./INSTALL.md).

## Login

Username `nixos`, password `eznix`.

Change the password once you are logged in: Start menu, System Settings, Users.

## Changing things later

1. Open **eznix** from the Start menu and log in with your username and password. (It is
   also at http://localhost:9090 in any browser.)
2. Change what you want and press **Save**.
3. Press **Activate**. Your changes are in use when it finishes.

The other buttons:

| Button | What it does |
|---|---|
| **Update** | Fetches newer versions of your programs. Press **Activate** after it |
| **List** | Shows the earlier versions of your system. You can start any of them from the menu shown when the computer starts |
| **Cleanup** | Removes those earlier versions to free disk space |

## What eznix looks after, and what you change as usual

eznix looks after the computer itself: which programs are installed, the desktop, the
services, the user accounts. Change those in eznix.

Your own settings are changed the way you always would: the theme, the wallpaper, the panel,
the screen layout, your browser and the settings of each program. Use System Settings or the
program itself. They are kept in your home folder, and **Activate** does not touch them.

## Editing files in the terminal

The text editor is **micro**. Press **Ctrl+S** to save and **Ctrl+Q** to quit.

To use another editor, open **eznix**, go to the **software** tab and add the editor under
`environment.systemPackages` (for example `pkgs.nano` or `pkgs.vim`). Then set
`environment.variables.EDITOR` in the same tab to its command (`nano`, `vim`) and press
**Save** and **Activate**. You can remove `pkgs.micro` once you no longer need it.

## The files

| | |
|---|---|
| `eznix/` | Your settings. This is what the page edits |
| `plugins/` | For add-ons. Empty to begin with |
| `flake.nix` | Ties it all together |
| `hardware-configuration.nix` | Describes your computer. Made during the install |
