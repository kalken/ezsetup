{
  description = "Template Nixos Setup";

  #! inputs
  inputs = {
    ##! nixpkgs
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";

    ##! eznix
    eznix.url = "github:kalken/eznix";
    eznix.inputs.nixpkgs.follows = "nixpkgs";
  };

  #! outputs
  outputs = inputs @ {
    self,
    eznix,
    ...
  }: {
    nixosConfigurations = {
      default = inputs.nixpkgs.lib.nixosSystem {
        system = "x86_64-linux";
        specialArgs = {inherit inputs;};
        modules = [
          # the editor
          eznix.nixosModules.default
          ./hardware-configuration.nix
          # what is Nix and not settings: overlays
          ./plugins
          # the configuration: the *.json files eznix edits
          (eznix.lib.jsonDir ./eznix)
        ];
      };
    };
  };
}
